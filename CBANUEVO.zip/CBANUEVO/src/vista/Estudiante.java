/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Emmanuel
 */
@Entity
@Table(name = "estudiante", catalog = "tallerdb", schema = "cba")
@NamedQueries({
    @NamedQuery(name = "Estudiante.findAll", query = "SELECT e FROM Estudiante e")
    , @NamedQuery(name = "Estudiante.findByIdEstudiante", query = "SELECT e FROM Estudiante e WHERE e.idEstudiante = :idEstudiante")
    , @NamedQuery(name = "Estudiante.findByNombre", query = "SELECT e FROM Estudiante e WHERE e.nombre = :nombre")
    , @NamedQuery(name = "Estudiante.findByApPaterno", query = "SELECT e FROM Estudiante e WHERE e.apPaterno = :apPaterno")
    , @NamedQuery(name = "Estudiante.findByApMaterno", query = "SELECT e FROM Estudiante e WHERE e.apMaterno = :apMaterno")
    , @NamedQuery(name = "Estudiante.findByCorreo", query = "SELECT e FROM Estudiante e WHERE e.correo = :correo")
    , @NamedQuery(name = "Estudiante.findByNumtel", query = "SELECT e FROM Estudiante e WHERE e.numtel = :numtel")
    , @NamedQuery(name = "Estudiante.findByIdResponsable", query = "SELECT e FROM Estudiante e WHERE e.idResponsable = :idResponsable")
    , @NamedQuery(name = "Estudiante.findByAsesorado", query = "SELECT e FROM Estudiante e WHERE e.asesorado = :asesorado")})
public class Estudiante implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_estudiante")
    private Integer idEstudiante;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "ap_paterno")
    private String apPaterno;
    @Column(name = "ap_materno")
    private String apMaterno;
    @Column(name = "correo")
    private String correo;
    @Column(name = "numtel")
    private String numtel;
    @Column(name = "id_responsable")
    private Integer idResponsable;
    @Column(name = "asesorado")
    private Boolean asesorado;

    public Estudiante() {
    }

    public Estudiante(Integer idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public Integer getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(Integer idEstudiante) {
        Integer oldIdEstudiante = this.idEstudiante;
        this.idEstudiante = idEstudiante;
        changeSupport.firePropertyChange("idEstudiante", oldIdEstudiante, idEstudiante);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        String oldNombre = this.nombre;
        this.nombre = nombre;
        changeSupport.firePropertyChange("nombre", oldNombre, nombre);
    }

    public String getApPaterno() {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno) {
        String oldApPaterno = this.apPaterno;
        this.apPaterno = apPaterno;
        changeSupport.firePropertyChange("apPaterno", oldApPaterno, apPaterno);
    }

    public String getApMaterno() {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) {
        String oldApMaterno = this.apMaterno;
        this.apMaterno = apMaterno;
        changeSupport.firePropertyChange("apMaterno", oldApMaterno, apMaterno);
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        String oldCorreo = this.correo;
        this.correo = correo;
        changeSupport.firePropertyChange("correo", oldCorreo, correo);
    }

    public String getNumtel() {
        return numtel;
    }

    public void setNumtel(String numtel) {
        String oldNumtel = this.numtel;
        this.numtel = numtel;
        changeSupport.firePropertyChange("numtel", oldNumtel, numtel);
    }

    public Integer getIdResponsable() {
        return idResponsable;
    }

    public void setIdResponsable(Integer idResponsable) {
        Integer oldIdResponsable = this.idResponsable;
        this.idResponsable = idResponsable;
        changeSupport.firePropertyChange("idResponsable", oldIdResponsable, idResponsable);
    }

    public Boolean getAsesorado() {
        return asesorado;
    }

    public void setAsesorado(Boolean asesorado) {
        Boolean oldAsesorado = this.asesorado;
        this.asesorado = asesorado;
        changeSupport.firePropertyChange("asesorado", oldAsesorado, asesorado);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEstudiante != null ? idEstudiante.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Estudiante)) {
            return false;
        }
        Estudiante other = (Estudiante) object;
        if ((this.idEstudiante == null && other.idEstudiante != null) || (this.idEstudiante != null && !this.idEstudiante.equals(other.idEstudiante))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "vista.Estudiante[ idEstudiante=" + idEstudiante + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
