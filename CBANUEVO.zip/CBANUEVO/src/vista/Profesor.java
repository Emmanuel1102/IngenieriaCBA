/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Emmanuel
 */
@Entity
@Table(name = "profesor", catalog = "tallerdb", schema = "cba")
@NamedQueries({
    @NamedQuery(name = "Profesor.findAll", query = "SELECT p FROM Profesor p")
    , @NamedQuery(name = "Profesor.findByIdProfesor", query = "SELECT p FROM Profesor p WHERE p.idProfesor = :idProfesor")
    , @NamedQuery(name = "Profesor.findByNombre", query = "SELECT p FROM Profesor p WHERE p.nombre = :nombre")
    , @NamedQuery(name = "Profesor.findByApPaterno", query = "SELECT p FROM Profesor p WHERE p.apPaterno = :apPaterno")
    , @NamedQuery(name = "Profesor.findByApMaterno", query = "SELECT p FROM Profesor p WHERE p.apMaterno = :apMaterno")
    , @NamedQuery(name = "Profesor.findByCorreo", query = "SELECT p FROM Profesor p WHERE p.correo = :correo")
    , @NamedQuery(name = "Profesor.findByNumtel", query = "SELECT p FROM Profesor p WHERE p.numtel = :numtel")
    , @NamedQuery(name = "Profesor.findByAsesora", query = "SELECT p FROM Profesor p WHERE p.asesora = :asesora")})
public class Profesor implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_profesor")
    private Integer idProfesor;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "ap_paterno")
    private String apPaterno;
    @Column(name = "ap_materno")
    private String apMaterno;
    @Column(name = "correo")
    private String correo;
    @Column(name = "numtel")
    private String numtel;
    @Column(name = "asesora")
    private Boolean asesora;

    public Profesor() {
    }

    public Profesor(Integer idProfesor) {
        this.idProfesor = idProfesor;
    }

    public Integer getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(Integer idProfesor) {
        Integer oldIdProfesor = this.idProfesor;
        this.idProfesor = idProfesor;
        changeSupport.firePropertyChange("idProfesor", oldIdProfesor, idProfesor);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        String oldNombre = this.nombre;
        this.nombre = nombre;
        changeSupport.firePropertyChange("nombre", oldNombre, nombre);
    }

    public String getApPaterno() {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno) {
        String oldApPaterno = this.apPaterno;
        this.apPaterno = apPaterno;
        changeSupport.firePropertyChange("apPaterno", oldApPaterno, apPaterno);
    }

    public String getApMaterno() {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) {
        String oldApMaterno = this.apMaterno;
        this.apMaterno = apMaterno;
        changeSupport.firePropertyChange("apMaterno", oldApMaterno, apMaterno);
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        String oldCorreo = this.correo;
        this.correo = correo;
        changeSupport.firePropertyChange("correo", oldCorreo, correo);
    }

    public String getNumtel() {
        return numtel;
    }

    public void setNumtel(String numtel) {
        String oldNumtel = this.numtel;
        this.numtel = numtel;
        changeSupport.firePropertyChange("numtel", oldNumtel, numtel);
    }

    public Boolean getAsesora() {
        return asesora;
    }

    public void setAsesora(Boolean asesora) {
        Boolean oldAsesora = this.asesora;
        this.asesora = asesora;
        changeSupport.firePropertyChange("asesora", oldAsesora, asesora);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idProfesor != null ? idProfesor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Profesor)) {
            return false;
        }
        Profesor other = (Profesor) object;
        if ((this.idProfesor == null && other.idProfesor != null) || (this.idProfesor != null && !this.idProfesor.equals(other.idProfesor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "vista.Profesor[ idProfesor=" + idProfesor + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
