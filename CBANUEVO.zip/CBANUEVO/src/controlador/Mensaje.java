/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import javax.swing.JOptionPane;

/**
 *
 * @author Emmanuel
 */
public class Mensaje {
    
    
    
    
  
    
    
     public void MensajeError(){
    
       JOptionPane.showMessageDialog(null, "Error en el usuario o contraseña  "); 
    };
     
     
      public void MensajeConfirmacion(){
    
       JOptionPane.showConfirmDialog(null, "¿Estas seguro de enviar el correo de confirmacion?");
    };
      
      
       public void MensajeBienvenida(){
        JOptionPane.showMessageDialog(null, "Bienvenido   ");
    
    };
      
     
     
     
}



